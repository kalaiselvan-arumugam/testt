package com.scb.services;

import org.apache.log4j.Logger;

import com.scb.log4jmask.helpers.CustomLogger;

public class SampleHostController {

	public String printCreditCardNumber(String creditCardNumber, String sessionId) {
		Logger hostLogger = CustomLogger.getLogger(sessionId);
		hostLogger.debug("Collected Credit Card Number : " + creditCardNumber);
		Logger ccLogger = Logger.getLogger("host");
		ccLogger.debug("Credit Card Number : " + creditCardNumber);
		return creditCardNumber + " Returned Value";
	}

	public static void main(String[] args) {
		SampleHostController sampleHostController = new SampleHostController();
		sampleHostController.printCreditCardNumber("4111111111111111", "1234");
	}
}